package package1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Base {

	public WebDriver driver;

	public Base(){
	    
		System.setProperty("webdriver.ie.driver", "C:/Raji/FIM/Selenium/Selenium/IEDriverServer_x64_3.13.0/IEDriverServer.exe");
		driver = new InternetExplorerDriver();
	    driver.get("https://www.google.com");
	}
}
