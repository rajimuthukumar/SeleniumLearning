package suiteMDRIM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Login {
	
	WebDriver driver;
	
	 public Login(WebDriver driver)
	  {
	    this.driver = driver;
	  }
	
	public void LoginPageFunc()
	  {
		 
		
	    WebElement username = driver.findElement(By.id("username"));
	    username.sendKeys(ExcelFunc.cellvalue1);
	    
	    WebElement password = driver.findElement(By.id("password"));
	    password.sendKeys(ExcelFunc.cellvalue2);
	    
	    WebElement signonbtn = driver.findElement(By.xpath("/html/body/div/div[2]/div[2]/form/a"));
	    signonbtn.click();
	    
	    
	  }

}
