package suiteMDRIM;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ExcelFunc {
	
	WebElement username; 
	static String cellvalue1,cellvalue2;
	
	public ExcelFunc(WebDriver driver) {
		// TODO Auto-generated constructor stub
		}

	
	public void MethodForExcelDec(int rowcounter) throws IOException 
	
		{
			
	        XSSFWorkbook srcBook = new XSSFWorkbook("C:\\Raji\\FIM\\MDRIM\\Datasheetnew.xlsx");     
	        XSSFSheet sourceSheet = srcBook.getSheetAt(0);
	        int rownum=rowcounter;
	        XSSFRow sourceRow = sourceSheet.getRow(rownum);
	        XSSFCell cell1=sourceRow.getCell(0);
	        XSSFCell cell2=sourceRow.getCell(1);
	        cellvalue1 = cell1.toString();
	        cellvalue2 = cell2.toString();
						
		}	
	
	
	
}
