package suiteMDRIM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Base1 {
	public WebDriver driver;

	public Base1(){
	    
		System.setProperty("webdriver.chrome.driver", "C:/Raji/FIM/Selenium/Selenium/chromedriver_win32/chromedriver.exe");
		driver = new ChromeDriver();
	    driver.navigate().to("https://jnjvldqa1.appiancloud.com/suite/sites/rim");
	    //driver.manage().window().maximize();
	    
	  
	    
	    
	    
	}
	
}
