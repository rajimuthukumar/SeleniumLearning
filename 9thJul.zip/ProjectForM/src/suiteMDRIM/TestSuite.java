package suiteMDRIM;

import java.io.IOException;

import org.testng.annotations.Test;

import package1.Base;
import package1.Function1;
import package1.UseFunction;
public class TestSuite {
	
	@Test
	public void testMethod1() throws IOException, InterruptedException
	{
		
		//Objects creation
		Base1 base = new Base1();
	    Login loginObj = new Login(base.driver);
	    ExcelFunc exeObj1 = new ExcelFunc (base.driver);
	    CreateNewStrategy createObj = new CreateNewStrategy(base.driver);
	    
	    
	    //Calling methods
	    exeObj1.MethodForExcelDec(1);
	    loginObj.LoginPageFunc();
	    createObj.funcCreateNew();
	    
	    
	    
	    
	    
	}
	

}
