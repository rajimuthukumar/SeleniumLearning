package suiteMDRIM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CreateNewStrategyForm {
	
	WebDriver driver;
	
	public CreateNewStrategyForm(WebDriver driver) {
		
		this.driver = driver;
		
	}
	
	public void StrategyForm() {
		
		WebElement txtProjectName = driver.findElement(By.xpath("//*[@id='bb83e61c89dab5a13f4ee86aecdb6f20']"));
		WebElement RAstrategyCat = driver.findElement(By.id("4e52418e0693f1fbbee94f64c4c44078_value"));
		WebElement ExpectedCountryDate = driver.findElement(By.id("597b904956ab4bc109e931904f1342c1"));
		WebElement IsUSExpApp = driver.findElement(By.xpath("//*[@for='70593f307a757c8df055d95bdd5bd1c9_1']"));
		WebElement RegSubRef = driver.findElement(By.id("94c48fb58fe8e52cb7d01e0ba65de7d4"));
		WebElement EstLegDocAva = driver.findElement(By.id("88309d6e200d1c1ac91a1a6a132a05cf"));
		WebElement IsCEApprovalApp = driver.findElement(By.xpath("//*[@for='96161ca75d8a882cc846e1e127f99b5e_1']"));
		WebElement ProjectLeadName = driver.findElement(By.id("7b0ef5109aafada6e9dfb435900fbde8"));
		WebElement ProjectAndPdtDes = driver.findElement(By.id("42d82338e74e1281c89cf16ca3ada9c8"));
		WebElement AddProInfoAtt = driver.findElement(By.xpath("//*[@for='e5db73fe3edaafde4d6684ba716d1b33_1']"));
		WebElement AddBU = driver.findElement(By.xpath("//*[contains(text(),'Add Business Unit')]"));
		WebElement BU = driver.findElement(By.id("d32c1baa3e10ad14d22b7c51f0ce52f1_value"));
		WebElement PLMNumber = driver.findElement(By.id("2513d1336f0fb35871a9548fcbb022d4"));
		WebElement RALeadName = driver.findElement(By.xpath("//*[@aria-labelledby ='0b96e8857005b4f97bc20eb7d700f965_column3_header']"));
		WebElement AddCountry = driver.findElement(By.xpath("//*[contains(text(),'Add/Remove Countries')]"));
		WebElement CountryGroup = driver.findElement(By.xpath("//*[@for=\'f9d0bcc0051987d9f600965bc8cd5777_0\']"));
		WebElement Country = driver.findElement(By.xpath("//*[@for=\'ca0005e9a1deec5b6bfc139226d54afd_row_selection_0_0\']"));
		WebElement Add = driver.findElement(By.xpath("//*[@class='Button---btn Button---default_direction appian-context-first-in-list appian-context-last-in-list' and contains(text(),'Add')]"));
		WebElement SaveCountriesReturn = driver.findElement(By.xpath("//*[contains(text(),'Save Countries & Return to Strategy')]"));
		
		
		
		
		
		
	}

}
