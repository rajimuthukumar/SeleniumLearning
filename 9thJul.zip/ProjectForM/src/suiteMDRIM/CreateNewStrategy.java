package suiteMDRIM;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections4.KeyValue;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CreateNewStrategy {
	
	WebDriver driver;
	
	//WebDriverWait  wait = new WebDriverWait(driver,45);
	
	 public CreateNewStrategy(WebDriver driver)
	  {
	    this.driver = driver;
	  }
	 
	 public void funcCreateNew() throws InterruptedException
	  {
		 //Clicking on 'Create New button'
		 
		Thread.sleep(9000);
		//driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		WebElement createnewbtn = driver.findElement(By.xpath("//img[@alt='Create New Strategy']"));

		 //wait.until(ExpectedConditions.visibilityOf(createnewbtn));
		 
		 createnewbtn.click();
		 
		 Thread.sleep(5000);
		 WebElement projectType = driver.findElement(By.id("189d67819beda8ebc9b5a2b7554f80f1_value"));
		 projectType.sendKeys("New Product Introduction");
		 projectType.sendKeys(Keys.ENTER);
		
		 WebElement btnNext = driver.findElement(By.xpath("//*[contains(text(),'Next')]"));
		 btnNext.click();
		 
	  }
	 	 
}


//