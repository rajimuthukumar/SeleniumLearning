package archived;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
	
	WebDriver driver;
	
	 public LoginPage(WebDriver driver)
	  {
	    this.driver = driver;
	  }
	 
	 public void LoginPageFunc()
	  {
		 
	    WebElement username = driver.findElement(By.id("username"));
	    WebElement password = driver.findElement(By.id("password"));
	    WebElement signonbtn = driver.findElement(By.xpath("/html/body/div/div[2]/div[2]/form/a"));
	  }

}
