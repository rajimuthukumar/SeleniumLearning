package package1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Function1 {
	
	WebDriver driver;
	
	 public Function1(WebDriver driver)
	  {
	    this.driver = driver;
	  }
	 
	 public void func2()
	  {
	    driver.findElement(By.name("btnK"));
	  }

}
