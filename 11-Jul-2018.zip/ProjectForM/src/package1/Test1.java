package package1;

import org.testng.annotations.Test;

public class Test1 {
	
	@Test
	public void testMethod1()
	{
	    Base base = new Base();
	    UseFunction funObj = new UseFunction(base.driver);
	    funObj.func1(); 
	    Function1 fun1Obj = new Function1(base.driver);
	    fun1Obj.func2();
	    
	    
	}


}
