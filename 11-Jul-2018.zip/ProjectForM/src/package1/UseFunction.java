package package1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class UseFunction {
	WebDriver driver;
	
	 public UseFunction(WebDriver driver)
	  {
	    this.driver = driver;
	  }
	 
	 public void func1()
	  {
	    driver.findElement(By.id("lst-ib")).sendKeys("abc");
	    
	  }

}
