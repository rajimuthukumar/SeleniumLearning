package suiteMDRIM;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class CreateNewStrategyForm {
	
	WebDriver driver;
	
	public CreateNewStrategyForm(WebDriver driver) {
		
		this.driver = driver;
		
	}
	
	public void ProjectGeneralInfo() throws InterruptedException, ParseException{
		Thread.sleep(7000);
		WebElement txtProjectName = driver.findElement(By.xpath("//*[@id='bb83e61c89dab5a13f4ee86aecdb6f20']"));
		WebElement RAstrategyCat = driver.findElement(By.id("4e52418e0693f1fbbee94f64c4c44078_value"));
		WebElement ExpectedCountryDate = driver.findElement(By.id("597b904956ab4bc109e931904f1342c1"));
		WebElement IsUSExpApp = driver.findElement(By.xpath("//span[text()='Is US Expected Approval Date Applicable?']/../following-sibling::div/div/div/label[text()='No']"));
		WebElement RegSubRef = driver.findElement(By.id("94c48fb58fe8e52cb7d01e0ba65de7d4"));
		WebElement EstLegDocAva = driver.findElement(By.id("88309d6e200d1c1ac91a1a6a132a05cf"));
		WebElement IsCEApprovalApp = driver.findElement(By.xpath("//span[text()='Is CE Expected Approval Date Applicable?']/../following-sibling::div/div/div/label[text()='No']"));
		WebElement ProjectLeadName = driver.findElement(By.id("7b0ef5109aafada6e9dfb435900fbde8"));
		WebElement ProjectAndPdtDes = driver.findElement(By.id("42d82338e74e1281c89cf16ca3ada9c8"));
		WebElement AddProInfoAtt = driver.findElement(By.xpath("//*[@for='e5db73fe3edaafde4d6684ba716d1b33_1']"));
		
		txtProjectName.sendKeys(ExcelFunc.cellvalue3);
		
		RAstrategyCat.sendKeys(ExcelFunc.cellvalue4);
		RAstrategyCat.sendKeys(Keys.ENTER);
		
		/*
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("MM/DD/YYYY");
		Date varDate1 = dateFormat1.parse(ExcelFunc.cellvalue5);
		ExpectedCountryDate.sendKeys(ExcelFunc.cellvalue5);*/
		
		ExpectedCountryDate.sendKeys("03/07/2018");
		ExpectedCountryDate.sendKeys(Keys.ENTER);
		ExpectedCountryDate.sendKeys(Keys.ENTER);
		
		
		IsUSExpApp.click();
		RegSubRef.sendKeys(ExcelFunc.cellvalue7);
		
		EstLegDocAva.sendKeys("03/08/2018");
		EstLegDocAva.sendKeys(Keys.TAB);
		
		
		
		IsCEApprovalApp.click();
		ProjectLeadName.sendKeys(ExcelFunc.cellvalue10);
		ProjectAndPdtDes.sendKeys(ExcelFunc.cellvalue11);
		AddProInfoAtt.click();
	}
	
	public void BUDetails() throws InterruptedException{
		WebElement AddBU = driver.findElement(By.xpath("//*[contains(text(),'Add Business Unit')]"));
		AddBU.click();
		Thread.sleep(15000);
		WebElement BU = driver.findElement(By.id("d32c1baa3e10ad14d22b7c51f0ce52f1_value"));
		BU.sendKeys(ExcelFunc.cellvalue6);
		BU.sendKeys(Keys.ENTER);
		Thread.sleep(5000);
		
		WebElement PLMNumber = driver.findElement(By.id("2513d1336f0fb35871a9548fcbb022d4"));
		PLMNumber.sendKeys(ExcelFunc.cellvalue8);
		
		WebElement RALeadName = driver.findElement(By.xpath("//*[@aria-labelledby ='0b96e8857005b4f97bc20eb7d700f965_column3_header']"));
		RALeadName.sendKeys(ExcelFunc.cellvalue13);
		Thread.sleep(7000);
		RALeadName.sendKeys(Keys.ENTER);
		
		WebElement StrategyOwner = driver.findElement(By.xpath("//*[@id=\"appian-body\"]/div/div/div/div/div/div[1]/div/div[3]/div/div/div/div/div/div/div[2]/div/div[1]/table/tbody/tr/td[5]/div/div/div/label"));
		StrategyOwner.click();
		
	}
	
	public void TargetedCountries() throws InterruptedException {
		
		Thread.sleep(7000);
		WebElement AddCountry = driver.findElement(By.xpath("//*[contains(text(),'Add/Remove Countries')]"));
		AddCountry.click();
		
		Thread.sleep(8000);
		WebElement CountryGroup = driver.findElement(By.xpath("//*[@class='CheckboxGroup---choice_label' and @for='f9d0bcc0051987d9f600965bc8cd5777_0']"));
		CountryGroup.click();
		
		Thread.sleep(7000);
		WebElement Country = driver.findElement(By.xpath("//*[@id=\"appian-body\"]/div/div/div/div/div/div/div/div[5]/div/div/div/div/div/div[1]/div[2]/div/div/table/tbody/tr[1]/td[1]"));
		Country.click();
		
		Thread.sleep(7000);
		WebElement Add = driver.findElement(By.xpath("//*[@class='Button---btn Button---default_direction appian-context-first-in-list appian-context-last-in-list' and contains(text(),'Add')]"));
		Add.click();
		
		Thread.sleep(7000);
		WebElement SaveCountriesReturn = driver.findElement(By.xpath("//*[contains(text(),'Save Countries & Return to Strategy')]"));
		SaveCountriesReturn.click();
	}
	
	public void ProductInformation() throws InterruptedException {
		
		Thread.sleep(5000);
		WebElement CurrentLegalManu = driver.findElement(By.xpath("//*[@aria-controls='7679b3f61b298e555e4e569f7dff8199_suggestions']"));
		CurrentLegalManu.sendKeys(ExcelFunc.cellvalue14);
		
		Thread.sleep(5000);
		CurrentLegalManu.sendKeys(Keys.ARROW_DOWN.ENTER);
					
		WebElement CurrentPhyManu = driver.findElement(By.xpath("//*[@aria-controls='4a5b95fd6c83ef2d542e8876a17d0d06_suggestions']"));
		CurrentPhyManu.sendKeys(ExcelFunc.cellvalue15);
		Thread.sleep(5000);
		CurrentPhyManu.sendKeys(Keys.ENTER);
				
		WebElement SearchSelect = driver.findElement(By.xpath("//*[@for='114db7bbc312f42d3190d74dd3f4c7f7_1']"));
		SearchSelect.click();
		
		Thread.sleep(5000);
		WebElement AddRemoveProducts = driver.findElement(By.xpath("//*[contains(text(),'Add/Remove Products') and @type='button']"));
		
		AddRemoveProducts.click();
		Thread.sleep(5000);
		
		//After click AddRevmove
		WebElement CriteriaAddCatalogNumber = driver.findElement(By.xpath("//*[contains(text(),'Add Catalog Number') and @class='GridFooter---add_grid_row_link elements---global_a']"));
		CriteriaAddCatalogNumber.click();
		Thread.sleep(5000);
		
		WebElement CriteriaCatalogNumber = driver.findElement(By.id("65bfded00a664d3820c61b22ab710a5a"));
		CriteriaCatalogNumber.sendKeys("00-20120-1-001");
		Thread.sleep(5000);	
	
		WebElement CriteriaButtonSearch = driver.findElement(By.xpath("//*[contains(text(),'Search') and @type='button']"));
		CriteriaButtonSearch.click(); 
		Thread.sleep(10000);
		
		//Selecting first row
		WebElement Selectbutton = driver.findElement(By.xpath("//*[@id=\"appian-body\"]/div/div/div/div/div/div/div/div[5]/div/div/div/div/div/div[2]/div[2]/div/div/table/tbody/tr/td[1]"));
		Selectbutton.click();
		Thread.sleep(15000);
		//After selecting product
		WebElement CriteriaAddtoStrategy = driver.findElement(By.xpath("//*[contains(text(),'Add to Strategy') and @type='button']"));
		CriteriaAddtoStrategy.click();
		Thread.sleep(5000);
		
		WebElement CriteriaSaveProduct = driver.findElement(By.xpath("//*[contains(text(),'Save Products and Return to Strategy') and @type='button']"));
		CriteriaSaveProduct.click();
		Thread.sleep(5000);
		
		WebElement Advancebutton = driver.findElement(By.xpath("//*[contains(text(),'Advance') and @type='button']"));
		Advancebutton.click();
		
		WebElement Yesbutton = driver.findElement(By.xpath("//*[@type='button' and @class='Button---btn Button---default_direction Button---primary appian-context-first-in-list appian-context-last-in-list']"));
		Yesbutton.click();
		
		WebElement ClickHere = driver.findElement(By.xpath("//*[contains(text(),'Click here')]"));
		ClickHere.click();
	}
	
}
