package suiteMDRIM;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ExcelFunc {
	
	WebElement username; 
	static String cellvalue1,cellvalue2;
	
	static String cellvalue3,cellvalue4,cellvalue6,cellvalue5,cellvalue8,cellvalue7,cellvalue10,cellvalue9,cellvalue12,cellvalue11,cellvalue13,cellvalue14,cellvalue15;
	
	public ExcelFunc(WebDriver driver) {
		// TODO Auto-generated constructor stub
		}

	
	public void MethodForExcelDec(int rowcounter) throws IOException 
	
		{
			
	        XSSFWorkbook srcBook = new XSSFWorkbook("C:\\Raji\\FIM\\MDRIM\\Datasheetnew.xlsx");     
	        XSSFSheet sourceSheet = srcBook.getSheetAt(0);
	        int rownum=rowcounter;
	        XSSFRow sourceRow = sourceSheet.getRow(rownum);
	        XSSFCell cell1=sourceRow.getCell(0);
	        XSSFCell cell2=sourceRow.getCell(1);
	        cellvalue1 = cell1.toString();
	        cellvalue2 = cell2.toString();
						
		}	
	
	public void MethodForStrategy(int rowcounter) throws IOException {
		
		XSSFWorkbook StrategyForm = new XSSFWorkbook("C:\\Raji\\FIM\\MDRIM\\TestData-Create New Strategy Form.xlsx");     
        XSSFSheet DataSheet = StrategyForm.getSheetAt(0);
        int rownum=rowcounter;
        XSSFRow DataRow = DataSheet.getRow(rownum);
        XSSFCell Projectname=DataRow.getCell(0);
        cellvalue3 = Projectname.toString();
        XSSFCell RAStrategyCat = DataRow.getCell(1);
        cellvalue4 = RAStrategyCat.toString();
        XSSFCell ExpCountDate = DataRow.getCell(2);
        cellvalue5 = ExpCountDate.toString();   
        XSSFCell RegSubReference = DataRow.getCell(4);
        cellvalue7 = RegSubReference.toString();
        XSSFCell IsCEExpected = DataRow.getCell(6);
        cellvalue9 = IsCEExpected.toString();
        XSSFCell ProjectLeadName  = DataRow.getCell(7);
        cellvalue10 = ProjectLeadName.toString();
        XSSFCell ProjectandProductDes  = DataRow.getCell(8);
        cellvalue11 = ProjectandProductDes.toString();
        XSSFCell AdditionalProjectInformation = DataRow.getCell(9);
        cellvalue12 = AdditionalProjectInformation.toString();      
        //Adding Business Unit
        XSSFCell BusinessUnit = DataRow.getCell(10);
        cellvalue6 = BusinessUnit.toString();
        XSSFCell PLMNumber = DataRow.getCell(11);
        cellvalue8 = PLMNumber.toString();
        XSSFCell RALeadName = DataRow.getCell(12);
        cellvalue13 = RALeadName.toString();
        XSSFCell CurrentLegal = DataRow.getCell(15);
        cellvalue14 = CurrentLegal.toString();
        XSSFCell CurrentPhy = DataRow.getCell(16);
        cellvalue15 = CurrentLegal.toString();
        
        
        
	}
	
	
	
}
