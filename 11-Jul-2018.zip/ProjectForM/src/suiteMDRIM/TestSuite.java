package suiteMDRIM;

import java.io.IOException;
import java.text.ParseException;

import org.testng.annotations.Test;

import package1.Base;
import package1.Function1;
import package1.UseFunction;
public class TestSuite {
	
	@Test
	public void testMethod1() throws IOException, InterruptedException, ParseException
	{
		
		//Objects creation
		Base1 base = new Base1();
	    Login loginObj = new Login(base.driver);
	    ExcelFunc exeObj1 = new ExcelFunc (base.driver);
	    CreateNewStrategy createObj = new CreateNewStrategy(base.driver);
	    CreateNewStrategyForm formObj = new CreateNewStrategyForm(base.driver);
	    
	    
	    //Calling methods
	    exeObj1.MethodForExcelDec(1);
	    loginObj.LoginPageFunc();
	    createObj.funcCreateNew();
	    exeObj1.MethodForStrategy(1);
	    formObj.ProjectGeneralInfo();
	    formObj.BUDetails();
	    formObj.TargetedCountries();
	    formObj.ProductInformation();
	    
	    
	    
	    
	    
	}
	

}
